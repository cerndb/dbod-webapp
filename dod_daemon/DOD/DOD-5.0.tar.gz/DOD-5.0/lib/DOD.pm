package DOD;

use strict;
use warnings;
use Exporter;

use YAML::Syck;
use File::ShareDir;
use Log::Log4perl;

use DBI;
use DBD::Oracle qw(:ora_types);
use POSIX qw(strftime);

use DOD::Database;

our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS, $config, $config_dir, $logger,
    $DSN, $DBTAG, $DATEFORMAT, $user, $password);

$VERSION     = 0.03;
@ISA         = qw(Exporter);
@EXPORT      = qw($config jobDispatcher);
@EXPORT_OK   = ( );
%EXPORT_TAGS = ( );

# Load general configuration

BEGIN{
$config_dir = File::ShareDir::dist_dir(__PACKAGE__);
$config = LoadFile( "$config_dir/dod.conf" );
Log::Log4perl::init( "$config_dir/$config->{'LOGGER_CONFIG'}" );
$logger = Log::Log4perl::get_logger( 'DOD' );
$logger->debug( "Logger created" );
$logger->debug( "Loaded configuration from $config_dir" );
foreach my $key ( keys(%{$config}) ) {
    my %h = %{$config};
    $logger->debug( "\t$key -> $h{$key}" );
    }
} # BEGIN BLOCK

sub jobDispatcher {
    # This is neccesary because daemonizing closes all file descriptors
    Log::Log4perl::init_and_watch( "$config_dir/$config->{'LOGGER_CONFIG'}", 60 );
    my $logger = Log::Log4perl::get_logger( "DOD.jobDispatcher" );
    my $dbh = DOD::Database::getDBH();
    my @tasks;
    my @job_list;
    while (1){
        $logger->debug( "Fetching job list" );
        push(@job_list, DOD::Database::getJobList($dbh));
        my $pendingjobs = $#job_list + 1;
        $logger->debug( "Pending jobs: $pendingjobs" );
        if ($#job_list >= 0){
            foreach my $job (@job_list){
                $logger->debug( "Number of open tasks: $#tasks" );
                if ($#tasks < 10){
                    my $worker_pid = fork();
                    if ($worker_pid){
                        $logger->debug( "Adding worker ($worker_pid) to pool" );
                        my $task = {};
                        $job->{'STATE'} = 'DISPATCHED';
                        $task->{'pid'} = $worker_pid;
                        $task->{'job'} = $job;
                        push(@tasks, $task);
                        # Updates job status to RUNNING
                        DOD::Database::updateJobState($job, "RUNNING", $dbh);
                    }
                    else{
                        &worker_body($job)
                    }
                }
                else {
                    $logger->debug( "Waiting for $#tasks tasks  completion" );
                    foreach my $task (@tasks) {
                        my $tmp = waitpid($task->{'pid'}, 0);
                        $logger->debug( "Done with worker : $tmp" );
                        $logger->debug( "Removing finished job from queue" );
                    }
                    $logger->debug( "Removing finished workers from pool" );
                    @tasks = grep(waitpid($_->{'pid'}, 0)>=0, @tasks);
                }
            }
        }
        else{
            $logger->debug( "No pending jobs. Sleeping"); 
        }
        # Remove dispatched jobs from joblist
        $logger->debug( "Cleaning Dispatched jobs from job list. #JOBS = $#job_list ");
        @job_list = grep( ( $_->{'STATE'} =~ 'PENDING' ), @job_list);
        $logger->debug( "Pending jobs after Dispatched jobs cleaning. #JOBS = $#job_list ");
        # Iteration timer
        sleep 20;
    }
}

sub worker_body {
    my $job = shift;
    my $logger = Log::Log4perl::get_logger( "DOD.worker" );
    my $dbh = DOD::Database::getDBH();
    my $cmd_line = DOD::Database::prepareCommand($job, $dbh);
    my $log;
    if (defined $cmd_line){
        my $cmd =  "syscontrol -i $job->{'DB_NAME'} $cmd_line";
        $logger->debug( "Executing $cmd" );
        $log = `echo $cmd`; # Just display to be executed command, and stores log
        $logger->debug( "Finishing Job");
        DOD::Database::finishJob( $job, "FINISHED_OK", $log, $dbh );
    }
    else{
        $logger->error( "An error ocurred preparing command execution" );
        DOD::Database::finishJob( $job, "FINISHED_FAIL", $log, $dbh );
    }
    $dbh->disconnect();
    exit 0;
}

# End of Module
END{

}

1;

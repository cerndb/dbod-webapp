package DOD::Database;

use strict;
use warnings;
use Exporter;

use YAML::Syck;
use File::ShareDir;
use Log::Log4perl;
use File::Temp;

use DBI;
use DBD::Oracle qw(:ora_types);
use POSIX qw(strftime);

use SysControl;

our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS, $config, $config_dir, $logger,
    $DSN, $DBTAG, $DATEFORMAT, $user, $password);

$VERSION     = 0.03;
@ISA         = qw(Exporter);
@EXPORT      = qw(getJobList updateJobState updateJobCompletionDate updateJobLog finishJob getDBH);
@EXPORT_OK   = qw(getDBH);
%EXPORT_TAGS = ( );

# Load general configuration

BEGIN{
$config_dir = File::ShareDir::dist_dir( "DOD" );
$config = LoadFile( "$config_dir/dod.conf" );
Log::Log4perl::init( "$config_dir/$config->{'LOGGER_CONFIG'}" );
$logger = Log::Log4perl::get_logger( 'DOD' );
$logger->debug( "Logger created" );
$logger->debug( "Loaded configuration from $config_dir" );
foreach my $key ( keys(%{$config}) ) {
    my %h = %{$config};
    $logger->debug( "\t$key -> $h{$key}" );
    }

# DB configuration parameters
$DSN = $config->{'DB_DSN'} ;
$DBTAG = $config->{'DB_USER'};
$DATEFORMAT = $config->{'DB_DATE_FORMAT'};
my @buf = split( /_/, $DBTAG );
$user = pop( @buf );
$password = SysControl::getPassword( $DBTAG );
if (defined $password){
    $logger->debug( "Testing database connection for $user:$DSN:XXXXXXXX" );
    my $dbh = DBI->connect( $DSN, $user, $password) ;
    $logger->debug( "Disconnecting" );
    $dbh->disconnect();
    }
else {
    $logger->error_die("Check DB connection parameters. Couldn't start a connection" );
}
} # BEGIN BLOCK

sub getJobList{
    my $dbh;
    if ($#_ == 0){
        $dbh = shift;
    }
    else{
        $dbh = getDBH();
    }
    my $sql = "select a.username, a.db_name, a.command_name, a.type, a.creation_date
        from dod_jobs a inner join (
            select username, db_name, min(creation_date) as creation_date 
            from dod_jobs
            where state = 'PENDING'
            group by username, db_name) b
        on a.username = b.username
        and a.db_name = b.db_name
        and a.creation_date = b.creation_date"; 
    $logger->debug( $sql );
    my $sth = $dbh->prepare( $sql );
    $logger->debug("Executing statement");
    $sth->execute();
    my @result;
    while ( my $ref = $sth->fetchrow_hashref() ){
        push @result, $ref;
        $logger->debug( "[New Job]");
        foreach my $key ( keys(%{$ref}) ) {
            my %h = %{$ref};
            $logger->debug( $key, "->", $h{$key} );
            }
        }
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 0){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
    return @result;
}   

sub updateInstanceState{
    my ($job, $state, $dbh);
    if ($#_ == 1){
        ($job, $state) = @_;
        $dbh = getDBH();
    }
    elsif($#_ == 2){
        ($job, $state, $dbh) = @_;
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "update DOD_INSTANCES set state = ?
    where username = ? and db_name = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $state);
    $sth->bind_param(2, $job->{'USERNAME'});
    $sth->bind_param(3, $job->{'DB_NAME'});
    $logger->debug("Executing statement");
    $sth->execute();
    $dbh->commit();
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 1){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
}

sub updateJobState{
    my ($job, $state, $dbh);
    if ($#_ == 1){
        ($job, $state) = @_;
        $dbh = getDBH();
    }
    elsif($#_ == 2){
        ($job, $state, $dbh) = @_;
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "update DOD_JOBS set state = ?
    where username = ? and db_name = ? and command_name = ? and type = ? and creation_date = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $state);
    $sth->bind_param(2, $job->{'USERNAME'});
    $sth->bind_param(3, $job->{'DB_NAME'});
    $sth->bind_param(4, $job->{'COMMAND_NAME'});
    $sth->bind_param(5, $job->{'TYPE'});
    $sth->bind_param(6, $job->{'CREATION_DATE'});
    $logger->debug("Executing statement");
    $sth->execute();
    $dbh->commit();
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 1){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
}

sub updateJobCompletionDate{
    my ($job, $dbh);
    if ($#_ == 1){
        ($job, $dbh) = @_;
    }
    elsif($#_ == 0){
        $job = shift;
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "update DOD_JOBS set COMPLETION_DATE = sysdate
    where username = ? and db_name = ? and command_name = ? and type = ? and creation_date = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $job->{'USERNAME'});
    $sth->bind_param(2, $job->{'DB_NAME'});
    $sth->bind_param(3, $job->{'COMMAND_NAME'});
    $sth->bind_param(4, $job->{'TYPE'});
    $sth->bind_param(5, $job->{'CREATION_DATE'});
    $logger->debug("Executing statement");
    $sth->execute();
    $dbh->commit();
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 0){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
}

sub updateJobLog{
    my ($job, $log, $dbh);
    if ($#_ == 2){
        ($job, $log, $dbh) = @_;
    }
    elsif ($#_ == 1){
        ($job, $log) = @_;
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "update DOD_JOBS set LOG = ?
    where username = ? and db_name = ? and command_name = ? and type = ? and creation_date = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $log);
    $sth->bind_param(2, $job->{'USERNAME'});
    $sth->bind_param(3, $job->{'DB_NAME'});
    $sth->bind_param(4, $job->{'COMMAND_NAME'});
    $sth->bind_param(5, $job->{'TYPE'});
    $sth->bind_param(6, $job->{'CREATION_DATE'});
    $logger->debug("Executing statement");
    $sth->execute();
    $dbh->commit();
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 1){
        $logger->debug( "Disconnectingnnecting from database" );
        $dbh->disconnect();
    }
}

sub finishJob{
    my ($job, $log, $state, $dbh);
    if ($#_ == 3){
        ($job, $log, $state, $dbh) = @_;
    }
    elsif($#_ == 2){
        ($job, $log, $state) = @_;
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return undef;
    } 
    $dbh = getDBH();
    $logger->debug( "Updating job Completion Date" );
    updateJobCompletionDate($job, $dbh);
    $logger->debug( "Updating job State" );
    updateJobState($job, $state, $dbh);
    $logger->debug( "Updating job LOG" );
    updateJobLog($job, $log, $dbh);
    $logger->debug( "Updating Instance State" );
    updateInstanceState($job, 'RUNNING', $dbh);
    if ($#_ == 2){
        $logger->debug( "Disconnectingnnecting from database" );
        $dbh->disconnect();
    }
}

sub getJobParams{
    my ($job, $dbh);
    if ($#_ == 1){
        ($job, $dbh) = @_;
    }
    elsif($#_ == 0){
        $job = shift;
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "select NAME, VALUE from DOD_COMMAND_PARAMS
    where USERNAME = ? and DB_NAME = ? and COMMAND_NAME = ? and TYPE = ? and CREATION_DATE = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $job->{'USERNAME'});
    $sth->bind_param(2, $job->{'DB_NAME'});
    $sth->bind_param(3, $job->{'COMMAND_NAME'});
    $sth->bind_param(4, $job->{'TYPE'});
    $sth->bind_param(5, $job->{'CREATION_DATE'});
    $logger->debug("Executing statement");
    $sth->execute();
    my @result;
    while ( my $ref = $sth->fetchrow_hashref() ){
        push @result, $ref;
    }
    my $res = \@result;
    if ($sth->rows == 0){
        $res = undef;
    }
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 0){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
    return $res; 
}

sub getExecString{
    my ($job, $dbh);
    if ($#_ == 1){
        ($job, $dbh) = @_;
    }
    elsif($#_ == 0){
        $job = shift;
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    my $sql = "select EXEC from DOD_COMMAND_DEFINITION
    where COMMAND_NAME = ? and TYPE = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $job->{'COMMAND_NAME'});
    $sth->bind_param(2, $job->{'TYPE'});
    $logger->debug("Executing statement");
    $sth->execute();
    my $ref = $sth->fetchrow_hashref();
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 0){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
    return $ref->{'EXEC'}; 
}

sub getConfigFile{
    my ($job, $file_type, $dbh);
    if ($#_ == 2){
        ($job, $file_type, $dbh) = @_;
    }
    elsif($#_ == 1){
        $job = shift; 
        $file_type = shift;
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    $dbh->{LongReadLen} = 32768; 
    my $sql = "select CONFIG_FILE from DOD_CONFIG_FILES
    where DB_NAME = ? and USERNAME = ? and FILE_TYPE = ?";
    $logger->debug( "Preparing statement: \n\t$sql" );
    my $sth = $dbh->prepare( $sql, { ora_pers_lob => 1 } );
    $logger->debug( "Binding parameters");
    $sth->bind_param(1, $job->{'DB_NAME'});
    $sth->bind_param(2, $job->{'USERNAME'});
    $sth->bind_param(3, $file_type);
    $logger->debug("Executing statement");
    $sth->execute();
    my $ref = $sth->fetchrow_hashref(); 
    my $result = $ref->{'CONFIG_FILE'}; 
    $logger->debug( "Finishing statement" );
    $sth->finish();
    if ($#_ == 0){
        $logger->debug( "Disconnecting from database" );
        $dbh->disconnect();
    }
    return $result;
}

sub prepareCommand {
    my ($job, $dbh);
    if ($#_ == 1){
        ($job, $dbh) = @_;
    }
    elsif($#_ == 0){
        $job = shift; 
        $dbh = getDBH();
    }
    else{
        $logger->error( "Wrong number of parameters" );
        return -1;
    }
    $logger->debug( "Fetching execution string" );
    my $cmd = $job->{'TYPE'} . '_' . lc($job->{'COMMAND_NAME'}) . ' ' . getExecString($job, $dbh);
    $logger->debug( " $cmd " );
    $logger->debug( "Fetching Job params" );
    my $params = getJobParams($job, $dbh);
    $logger->debug( "Disconnecting from DB" );
    my $nparams = scalar(@{$params});
    my $expected_nparams = 0;
    $expected_nparams++ while ($cmd =~ m/:/g);
    # This won't be needed for all the jobs
    my $tempdir = File::Temp::tempdir( 'dod_job_XXXX', DIR => '/tmp/', CLEANUP => 1 );
    if ($nparams == $expected_nparams){
        foreach my $param (@{$params}){
            if ($param->{'NAME'} =~ /FILE/){
                my ($fh, $filename) = File::Temp::tempfile( DIR => $tempdir );
                my $clob = getConfigFile($job, $param->{'VALUE'});
                $logger->debug( "$clob" );
                print $fh $clob;
                $cmd =~ s/:$param->{'NAME'}/$filename/;
                }
            else{
                $cmd =~ s/:$param->{'NAME'}/$param->{'VALUE'}/;
                }
            }
        my $buf;
        $buf++ while ($cmd =~ m/:/g);
        if ($buf) {
            $logger->error( "Some of the command parameters could not be parsed ");
            return undef;
            }
        #Distribute Required files, if any
        $logger->debug( "Copying files" );
        SysControl::copyToEntity($tempdir, "dod_ignacio");
        $logger->debug( "Deleting temporal files");
        system("rm -fr $tempdir");
        if ($#_ == 0){
            $logger->debug("Disconnecting from database");
            $dbh->disconnect();
            }
        return $cmd;
    }
    else {
        $logger->error( "The number of parameters is wrong. $expected_nparams expected, $nparams obtanied." );
        return undef;
    }
}

sub getDBH{
    my $dbh = DBI->connect( $DSN, $user, $password, { AutoCommit => 1 }) ;
    $logger->debug( "Setting date format: $DATEFORMAT" );
    $dbh->do( "alter session set NLS_DATE_FORMAT='$DATEFORMAT'" );
    return $dbh;
}

# Misc functions
sub myLocalTime{
    return strftime("%a %b %e %H:%M:%S %Y", localtime);
}

# End of Module
END{

}

1;

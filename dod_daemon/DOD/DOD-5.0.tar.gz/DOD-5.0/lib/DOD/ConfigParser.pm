package DOD::ConfigParser;

use strict;
use warnings;
use Exporter;

use DOD;

our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS, $logger, %get_parser);

$VERSION     = 0.03;
@ISA         = qw(Exporter);
@EXPORT      = qw(%get_parser MYSQL_stringParser);
@EXPORT_OK   = ( );
%EXPORT_TAGS = ( );

# Load general configuration

BEGIN{
$logger = Log::Log4perl::get_logger( 'DOD.ConfigParser' );
$logger->debug( "Logger created" );
foreach my $key ( keys(%{$config}) ) {
    my %h = %{$config};
    $logger->debug( "\t$key -> $h{$key}" );
    }
} # BEGIN BLOCK

sub MYSQL_fileParser{
    my $filename = shift;
    open (FP, "$filename") || die "Can't open $filename: $!\n";
    my $buf = <FP>;
    close(FP);
    return MYSQL_stringParser($buf);
}

sub MYSQL_stringParser
{
    my $clob = shift;
    my (%hash, $section, $keyword, $value);
    my $buf = {};
    my @lines = split(/\n/, $clob);
    foreach (@lines) {
        next if /^#/ or /^(\s)*$/;
        chomp;
        if (/^\s*\[(\w+)\].*/) {
            if (defined $buf && defined $section){
                $hash{$section} = $buf ;
                $buf = {};
                }
            $section = $1;
        }
        elsif (/.*=.*/) {
            my ($k,$v) = split(/\s*=\s*/, $_);
            $keyword = $k;
            $value = $v ;
            $buf->{$keyword} = $value;
        }
        elsif (/^s*(.*)?$/){
            $keyword = $1;
            $buf->{$keyword} = "";
        }
    }
    return \%hash;
}

sub MYSQL_writeFile{
    my ($hashref, $filename) = @_;
    open(FP, ">$filename") or die "Error opening file";
    while ( my($section, $valueref) = each( %{$hashref} ) ){
        print FP "[$section]\n";
        my %values = %{$valueref};
        foreach (keys (%values)){
            if ($values{$_}){
                print FP "$_ = $values{$_}\n";
            }
            else{
                print FP "$_\n";
            }
        }
    }
    close(FP);
}

sub MYSQLconfigEnforce{
    my ($new_config, $reference) = @_;
    my $res = {};
    while ( my($section, $new_paramsref) = each( %{$new_config} ) ){
        my %new_params = %{$new_paramsref};
        my %ref;
        my %buf = (); 
        if ($reference->{$section}){
            %ref = %{$reference->{$section}};
        }
        else{
            %ref = ();
        }
        foreach (keys (%new_params)){
            if ($ref{$_}){
                # If some additional test is to be done. It should be done here.
                # Boundary limits can be added with additional parameters
                $buf{$_} = $ref{$_};
            }
            else{
                $buf{$_} = $new_params{$_};
            }
        }
        $res->{$section} = \%buf;
    }
    return $res;
}

%get_parser = ("mysql" => \&MySQL_Parser);

# End of Module
END{

}

1;
